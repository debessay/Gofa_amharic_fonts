# Geez_Gofa_mono_C

Free monospace font for Ge'ez / Amharic (Ethiopic) and Latin, covering 578 characters. Licensed under the SIL Open Font License 1.1.

![Geez_Gofa_mono_C preview](Screenshot_Gofa_mono.png)

## Download

**[⬇ Download Geez_Gofa_mono_C v1.0](https://github.com/debessay/Geez_monospace_font/releases/tag/V1.0)**: OTF, TTF and WOFF2. The individual files are also in the [`font/`](font/) folder.

## Installation

### Desktop
- **Windows:** right-click the `.ttf` or `.otf` file and choose **Install**.
- **Mac:** double-click the `.ttf` or `.otf` file, then click **Install Font**.

### Web (jsDelivr CDN)

```css
@font-face {
  font-family: 'Geez_Gofa_mono_C';
  src: url('https://cdn.jsdelivr.net/gh/debessay/Geez_monospace_font@main/font/Geez_Gofa_mono_C_200_regular_normal_plain.woff2') format('woff2');
  font-weight: 400;
  font-style: normal;
  font-display: swap;
}

code, pre {
  font-family: 'Geez_Gofa_mono_C', monospace;
}
```

---

## Font Information

**Family Name:** -----Geez_Gofa_mono_C  
**Style Name:** ------Regular  
**Weight:** ----------Regular (400)  
**Width:** -----------Normal  
**Slope:** -----------Plain (Upright)  
**Type:** ------------Monospace  
**Monospaced Width:** 2400  
**Full Name:** -------Geez_Gofa_mono_C Regular  
**PostScript Name:** -GeezGofamonoCRegular  
**File Formats:** ----TTF, OTF, WOFF2  

---

## Supported Unicode Ranges

| Block                      | Unicode Range      | Characters Supported | Description                          |
|----------------------------|--------------------|----------------------|--------------------------------------|
| **Basic Latin**            | U+0000 – U+007F    | 93 / 97              | English letters, numbers, symbols    |
| **Ethiopic**               | **U+1200 – U+137F**| **357**              | **Core Amharic & Ge’ez**             |
| **Ethiopic Supplement**    | U+1380 – U+139F    | 16 / 26              | Additional Ge’ez syllables           |
| **Ethiopic Extended**      | U+2D80 – U+2DDF    | 77 / 79              | Gurage, Sebat Bet, etc.              |
| **Ethiopic Extended-A**    | U+AB00 – U+AB2F    | 32                   | Blin & modern extensions             |

**Total Characters Supported: 578**

---

## License

Geez_Gofa_mono_C is licensed under the [SIL Open Font License 1.1](OFL.md) (also in [OFL.txt](OFL.txt)).
Amharic summary of the license: [Amharic_licence.md](Amharic_licence.md).
